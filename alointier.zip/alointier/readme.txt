:: Première partie ::

J'ai tout d'abord créé les deux nouveaux utilisateurs: user1 et user2.
Pour cela j'ai utilisé la commande "adduser".

Ensuite, j'ai créé le répertoire ionis_arbo avec la commande "mkdir".

Pour me déplacer dans l'arborescence du système, je me suis servie de la commande cd.

Afin de créer tous les répertoires et fichiers, j'ai fait appel à la commande "mkdir pr les répertoires et la commande touch pour les fichiers.
Exemple: mkdir dir142 dir302
touch file115.txt .file166.zip

Pour les fichiers avec liens, j'ai utilisé la fonction "ln" et l'option "-s" pour les liens symboliques
Exemple: ln file442 file613
ln -s file442 file57

Pour créer les fichiers spéciaux, j'ai employé la commande "mknod"
p pour une FIFO, b pour un fichier spécial en mode bloc et c pour un fichier spécial en mode caractère
Exemple: mknod filep p
mknod fileb b 7 0
mknod null c 1 3

Après, je me suis occupée des assignations des droits.
La commande "chown" pour l'appartenance.
Exemple: user1:user1 dir142 dir673
 
La commande "chmod" pour les droits de lecture et d'écriture.
Exemple: chmod 1777 dir738.d
chmod 2663 file593
chmod 4235 .file166.zip

J'ai choisi la méthode des chiffres car je la trouvais plus rapide.

Enfin j'ai crée le fichier my_arbo.txt où j'y ai intégré le répertoire ionis_arbo avec la commande suivante:

ls -alR ionis_arbo > my_arbo.txt


:: Deuxième partie ::

Afin de récupérer les informaions du site de l'équipe de France de football, j'ai taper l'instruction suivante:

wget http://www.fff.fr/equipes-de-france/1/france-a/dernière-selection
Le résultat obtenu est enregistré dans dernière-selection

J'ai décidé de découper par étapes le travail à faire. J'ai donc créé les fichiers prenoms.txt noms.txt et dates.txt avec la commande touch

De là, j'ai pu extraire les informations nécessaires et les mettre dans leur fichier correspondant.
Les trois commandes utilisées sont:
Pour les noms:
grep player/popin derniere-selection | grep -oE '([A-Z]{3,20})' > noms.txt

Pour les prénoms:
grep player/popin derniere-selection | sed -e s/clicklink\"\>/\\n/g | grep -oE '^([A-Z][a-zA-Z0-9&#;]*)' > prenoms.txt

Pour les dates de naissance:
grep player/popin derniere-selection | grep -oE '([0-9]{2}/){2}[0-9]{4}' > dates.txt


Pour finir, j'ai regroupé ces résultats dans un même fichier avec l'affichage désiré.
paste prenoms.txt noms.txt dates.txt | awk -F" " '{print $1 ";" $2 ";" $3}' > my_france.txt
